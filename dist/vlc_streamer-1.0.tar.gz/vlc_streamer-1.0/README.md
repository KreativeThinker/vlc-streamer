# vlc-streamer
A python based vlc music engine. Allows for searching, playing and downloading music. Part of Project SongNova.

Dependencies:
    - python-youtube-music (link)
    - python-vlc (link)
    - pafy (modified)

## TODO:

- Create the search class `VLCStreamer.search(query: str)`
- Add Documentation of the `Search` class and add type hinting.